# The combofont package

An EXPERIMENTAL package to add nfss-declaration of combo fonts to a luaLaTeX document

Version 0.2 copyright Ulrike Fischer 2017-


## License

LATEX Project Public License 1.3c.

## Contents

- Readme.md (this file)
- combofont.sty (the sty)
- combofont.tex, combofont.pdf (the docu and example)
- combofont-test-fira-math.tex and pdf (and example for math)


## Installation

Put the sty where it can be found.

